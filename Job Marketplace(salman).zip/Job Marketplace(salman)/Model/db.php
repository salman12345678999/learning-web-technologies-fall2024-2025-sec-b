<?php
$host = 'localhost'; // Change this if using a different host
$user = 'root';      // Default username for phpMyAdmin
$password = '';      // Default password for phpMyAdmin (leave blank if none)
$database = 'job_marketplace'; // Name of your database

// Create a connection
$conn = new mysqli($host, $user, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
