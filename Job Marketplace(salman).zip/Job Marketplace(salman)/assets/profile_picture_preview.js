// Function to preview the selected image
function previewImage(event) {
    const reader = new FileReader();
    reader.onload = function () {
        const output = document.getElementById('preview-image');
        output.src = reader.result; // Set the image source to the file content
        output.style.display = 'block'; // Make the preview image visible
    };
    reader.readAsDataURL(event.target.files[0]); // Read the uploaded file as a data URL
}
