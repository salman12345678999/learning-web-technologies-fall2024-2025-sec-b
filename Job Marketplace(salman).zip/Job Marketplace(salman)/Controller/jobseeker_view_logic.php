<?php
include '../Model/db.php';
$user_id = $_GET['user_id'];

$query = "SELECT * FROM users WHERE user_id = $user_id AND user_type = 'Job Seeker'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "<h2>" . htmlspecialchars($user['full_name']) . "</h2>";
    echo "<p>Email: " . htmlspecialchars($user['email']) . "</p>";
    echo "<p>Date of Birth: " . htmlspecialchars($user['dob']) . "</p>";
    echo "<p>Gender: " . htmlspecialchars($user['gender']) . "</p>";
    echo "<p>Address: " . htmlspecialchars($user['address']) . "</p>";
} else {
    echo "<p>No job seeker profile found.</p>";
}
?>
