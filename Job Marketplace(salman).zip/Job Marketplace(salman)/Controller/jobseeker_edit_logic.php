<?php
include '../Model/db.php';
$user_id = $_GET['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];

    $query = "UPDATE users SET full_name='$full_name', email='$email', dob='$dob', gender='$gender', address='$address' WHERE use_id=$user_id";
    $conn->query($query);
    header("Location: ../View/jobseeker_view.php?use_id=$user_id");
}

$query = "SELECT * FROM users WHERE use_id = $user_id AND user_type = 'Job Seeker'";
$result = $conn->query($query);
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "<form method='POST'>
        <label for='full_name'>Full Name:</label>
        <input type='text' use_id='full_name' name='full_name' value='" . htmlspecialchars($user['full_name']) . "' required>

        <label for='email'>Email:</label>
        <input type='email' use_id='email' name='email' value='" . htmlspecialchars($user['email']) . "' required>

        <label for='dob'>Date of Birth:</label>
        <input type='date' use_id='dob' name='dob' value='" . htmlspecialchars($user['dob']) . "' required>

        <label for='gender'>Gender:</label>
        <select use_id='gender' name='gender'>
            <option " . ($user['gender'] === 'Male' ? 'selected' : '') . ">Male</option>
            <option " . ($user['gender'] === 'Female' ? 'selected' : '') . ">Female</option>
            <option " . ($user['gender'] === 'Other' ? 'selected' : '') . ">Other</option>
        </select>

        <label for='address'>Address:</label>
        <textarea use_id='address' name='address' required>" . htmlspecialchars($user['address']) . "</textarea>

        <button type='submit'>Save Changes</button>
    </form>";
} else {
    echo "<p>No job seeker profile found to edit.</p>";
}
?>