<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: signin.php');
    exit();
}

// Include the database connection
include '../Model/db.php';

// Retrieve user details from the database
$user_id = $_SESSION['user_id']; // Use the user_id stored in the session
$query = $conn->prepare("SELECT full_name FROM users WHERE id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc(); // Fetch user details as an associative array
    $full_name = $user['full_name']; // Extract the user's full name
} else {
    // If user not found, log them out and redirect
    session_destroy();
    header('Location: signin.php');
    exit();
}

if (!isset($_SESSION['user_id'])) {
    error_log("Session 'user_id' is not set.");
} else {
    error_log("Session 'user_id': " . $_SESSION['user_id']);
}

if ($result->num_rows === 0) {
    error_log("No user found in the database for user_id: $user_id");
} else {
    error_log("User found: " . print_r($user, true));
}

?>
