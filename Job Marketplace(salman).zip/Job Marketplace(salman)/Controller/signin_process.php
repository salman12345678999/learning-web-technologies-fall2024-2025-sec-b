<?php
session_start();
include '../Model/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Check if the user exists
    $query = $conn->prepare("SELECT id, full_name, user_type, password_hash FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $query->bind_result($id, $fullName, $userType, $passwordHash);

    if ($query->fetch()) {
        // Verify password
        if (password_verify($password, $passwordHash)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['name'] = $fullName;
            $_SESSION['user_type'] = $userType;

            header('Location: ../View/dashboard_view.php');
            exit();
        } else {
            $_SESSION['error'] = 'Invalid email or password.';
            header('Location: ../View/signin.php');
            exit();
        }
    } else {
        $_SESSION['error'] = 'Invalid email or password.';
        header('Location: ../View/signin.php');
        exit();
    }
}error_log("User ID in session: " . $_SESSION['user_id']);

?>
