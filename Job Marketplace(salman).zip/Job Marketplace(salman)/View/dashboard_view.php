<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../assets/styles.css">
</head>
<body>
    <header>
        <h1>Job Marketplace</h1>
    </header>
    <main>
        <!-- Display the user's full name -->
        <h1>Welcome, <?= isset($users['full_name']) ? htmlspecialchars($users['full_name']) : 'Kabya Das' ?>!</h1>
        <p>Select an option from the menu below to manage your account or explore features.</p>
        
        <div class="menu">
            <a href="../View/employer_edit.php" class="btn">Employer Editprofile</a>
            <a href="../View/employer_view.php" class="btn">Employer profile</a>
            <a href="../View/jobseeker_view.php" class="btn">Jobseeker profile</a>
            <a href="../View/jobseeker_edit.php" class="btn">Jobseeker Editprofile</a>
            <a href="../Controller/logout.php" class="btn btn-danger">Logout</a>
        </div>
    </main>
    <footer>
        &copy; 2024 Job Marketplace
    </footer>
</body>
</html>
